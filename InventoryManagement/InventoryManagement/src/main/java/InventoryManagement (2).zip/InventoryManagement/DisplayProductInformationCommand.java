package InventoryManagement;

public class DisplayProductInformationCommand extends Command
{    

    public DisplayProductInformationCommand(ProductCatalog productCatalog, User loggedOnUser)
    {
        //Calls the parent class(Command) constructor
        super(productCatalog, loggedOnUser);

    }

    @Override
    public void Execute() {
        // TODO Add the code that will execute this command

    }
}