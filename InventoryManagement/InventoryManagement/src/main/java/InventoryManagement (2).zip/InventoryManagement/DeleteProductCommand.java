//Student ID: cjw220005
//Name: Christopher Wiratman
package InventoryManagement;

public class DeleteProductCommand extends Command
{


    public DeleteProductCommand(ProductCatalog productCatalog, User loggedOnUser)
    {
        //Calls the parent class(Command) constructor
        super(productCatalog, loggedOnUser);

    }

    @Override
    public void Execute() {
        // TODO Add the code that will execute this command

        

        //This function will, being from DeleteProductCommand,
        //delete a product to the product catalog and file

    }
}
