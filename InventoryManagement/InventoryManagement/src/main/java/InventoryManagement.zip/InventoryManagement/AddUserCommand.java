package InventoryManagement;

public class AddUserCommand extends Command
{
    public AddUserCommand(ProductCatalog productCatalog, User loggedOnUser)
    {
        //Calls the parent class(Command) constructor
        super(productCatalog, loggedOnUser);

    }


    @Override
    public void Execute()
    {
        // TODO Add the code that will execute this command

            //1. Prompt user for first name, last name, password
            //and if they are a manager or not
            
            //2. Open the file and and append the user info
            //to a new line at the bottome of the file

            //3. Close the file and say user successfully added

        //This function will replace the old password of the user in the
        //file with the new password.
    }
}