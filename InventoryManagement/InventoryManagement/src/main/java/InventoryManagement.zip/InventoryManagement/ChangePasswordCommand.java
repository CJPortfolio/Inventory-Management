package InventoryManagement;

public class ChangePasswordCommand extends Command
{
    public ChangePasswordCommand(ProductCatalog productCatalog, User loggedOnUser)
    {
        //Calls the parent class(Command) constructor
        super(productCatalog, loggedOnUser);

    }


    @Override
    public void Execute()
    {
        // TODO Add the code that will execute this command

        //This function will replace the old password of the user in the
        //file with the new password.
    }
}


